## Welcome to SZSsim_tml ##
============================
SZSsim_tml is NETS ISO8583 eftpos terminal simulator on your laptop.
It's named after the son of the code developer. 
The whole idea of this tool is for code developer or tester to cut off testing time and 
can spent more quality time for something more important aspect in their life. 
Example like playing with their kids.

NETS ISO 8583 EFTPOS Terminal Simulator.
Command Line Interface (CLI) to support interactive, automation regression and load test.
Author: Susanto
Version: 1.05(Nov 2021)

Usage:
   SZSsim_tml.exe {flags}
   SZSsim_tml.exe <command> {flags}

Commands:
   help                          displays usage information
   loadtest                      load test
   regression                    auto regression
   version                       displays version number

Flags:
   -d, --debug                   on/off (default: off)
   -h, --help                    displays usage information of the application or a command (default: false)
   -i, --ip                      ip:port of EFTPOS host. Optional when pre-configured (default: 10.4.100.22:9101)
   -v, --version                 displays version number (default: false)
   
   
Configuration in properties.ini file.
   

** interactive mode **     
---------------------- 
Example:
SZSsim_tml.exe -i=10.4.100.22:9101
SZSsim_tml.exe --help
SZSsim_tml.exe -h
SZSsim_tml.exe
SZSsim_tml.exe --ip=10.4.100.22:9101
SZSsim_tml.exe --version
SZSsim_tml.exe -v 
SZSsim_tml.exe --ip=10.4.100.22:9101 --debug=on

Result:
log file in log/log-yyyy-mm-dd_hhmm.log


** regression mode **  
---------------------
This command run auto regression

Usage:
   SZSsim_tml.exe {flags}

Flags:
   -d, --debug                   on/off (default: off)
   -h, --help                    displays usage information of the application or a command (default: false)
   -i, --ip                      ip:port of EFTPOS host. Optional when pre-configured (default: 10.4.100.22:9101)
   -m, --mode                    reg mode value: 'all' or 'basic', to test all or basic test cases (default: all)
   -r, --rate                    rate, number in mins for regression auto sending (default: 1)
   
Example:
SZSsim_tml.exe regression --help
SZSsim_tml.exe regression -h
SZSsim_tml.exe regression
SZSsim_tml.exe regression --mode=basic
SZSsim_tml.exe regression --ip=10.4.100.22:9101
SZSsim_tml.exe regression --ip=10.4.100.22:9101 --mode=all --rate=1
SZSsim_tml.exe regression --ip=10.4.100.22:9101 --mode=basic --rate=2
SZSsim_tml.exe regression --ip=10.4.100.22:9101 -m=basic
SZSsim_tml.exe regression --ip=10.4.100.22:9101 -r=15
SZSsim_tml.exe regression -i=10.4.100.22:9101
SZSsim_tml.exe regression --ip=10.4.100.22:9101 --mode=basic --rate=2 --debug=on

Result:
log file in log/log-yyyy-mm-dd_hhmm.log
regression result in rpt/regression-rpt-yyyy-mm-dd_hhmm.pdf
SIT result in rpt/SIT Test Cases v1.0.xlsx

** loadtest **  
---------------------
This command run the load test

Usage:
   SZSsim_tml.exe {flags}

Flags:
   -d, --debug                   on/off (default: off)
   -c, --count                   total count/number of messages pumped for load test (default: 100)
   -h, --help                    displays usage information of the application or a command (default: false)
   -i, --ip                      ip:port of EFTPOS host. Optional when pre-configured (default: 10.4.100.22:9101)
   -t, --thread                  number of thread/server connections. Max 128 (default: 2)
   
Example:
SZSsim_tml.exe loadtest --help
SZSsim_tml.exe loadtest -h
SZSsim_tml.exe loadtest
SZSsim_tml.exe loadtest --count=1200 --thread=8 
SZSsim_tml.exe loadtest --thread=64 --count=1000
SZSsim_tml.exe loadtest --thread=4 -c=500
SZSsim_tml.exe loadtest -t=8
SZSsim_tml.exe loadtest -c=600
SZSsim_tml.exe loadtest --count=1200 --thread=8 --debug=on

Result:
log file in log/log-yyyy-mm-dd_hhmm.log
load test result in rpt/loadtest-rpt-yyyy-mm-dd_hhmm.pdf

